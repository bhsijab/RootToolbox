package com.bhsijab.roottoolbox

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildHome())
    }

    private fun buildHome(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
            setBackgroundColor(Color.WHITE)
        }

        root.addView(TextView(this).apply {
            text = "RootToolbox"
            textSize = 30f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.BLACK)
        })

        root.addView(TextView(this).apply {
            text = "Android Root 工具箱 · v0.1.0"
            textSize = 15f
            setTextColor(Color.DKGRAY)
            setPadding(0, 8, 0, 32)
        })

        addTool(root, "Applications", "应用管理")
        addTool(root, "Root Status", "检查 Root 环境")
        addTool(root, "Shell", "命令行工具")
        addTool(root, "System Info", "设备与系统信息")
        addTool(root, "About", "项目与版本信息")
        return root
    }

    private fun addTool(parent: LinearLayout, title: String, description: String) {
        val item = TextView(this).apply {
            text = "$title\n$description"
            textSize = 18f
            setTextColor(Color.BLACK)
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.rgb(245, 245, 245))
            setOnClickListener {
                Toast.makeText(this@MainActivity, "$title 模块正在建设中", Toast.LENGTH_SHORT).show()
            }
        }
        parent.addView(item, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = 16 })
    }
}
